﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Shell;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Threading;
using Humanitarian_Reader.Resources;
using System.Windows.Markup;

namespace Humanitarian_Reader.views
{
    public partial class ArticleView : PhoneApplicationPage
    {
        public ArticleView()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {

            //if (!App.ViewModel.IsDataLoaded)
            //{
            //    App.ViewModel.LoadData();
            //}

            string strTemp;
            NavigationContext.QueryString.TryGetValue("RSSFeed", out strTemp);

            if (strTemp != null)
            {
                // store this RSS feed as appication state data.
                // This helps in hadling navigating between multiple pages ...
                PhoneApplicationService.Current.State["RSSFeed"] = strTemp;

                SetUILanguage();
            }

            // Fetch the RSS items using the helper and set this to the listbox controls
            WindowsPhone.Helpers.RssService.GetRssItems(PhoneApplicationService.Current.State["RSSFeed"].ToString(),
                (items) => { ArticleList.ItemsSource = (List<WindowsPhone.Helpers.RssItem>)items; },
                (exception) => { MessageBox.Show(exception.Message); },
                null
                );

            
        }

        private void SetUILanguage()
        {
             ArticleList.Language = XmlLanguage.GetLanguage(AppResources.ResourceLanguage);
//            ArticleViewAppTitleTextBlock
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Jump to Home page
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }

        private void HyperlinkButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to Browser.xaml with the the selected article as value
            string selectedArticle = "/Browser.xaml?SelectedArticle=" + ((System.Windows.Controls.TextBlock)sender).Tag.ToString();
            NavigationService.Navigate(new Uri(selectedArticle, UriKind.Relative));
        }
    }
}