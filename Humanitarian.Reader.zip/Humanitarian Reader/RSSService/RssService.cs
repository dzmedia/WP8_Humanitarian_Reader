﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.ServiceModel.Syndication;
using System.Xml;

namespace WindowsPhone.Helpers
{
    /// <summary>
    /// Provides facade for accessing RSS service
    /// </summary>
    public static class RssService
    {

        /// <summary>
        /// Gets the RSS items.
        /// </summary>  
        /// <param name="rssFeed">The RSS feed.</param>
        /// <param name="onGetRssItemsCompleted">The on get RSS items completed.</param>
        /// <param name="onError">The on error.</param>
        public static void GetRssItems(string rssFeed, Action<IEnumerable<RssItem>> onGetRssItemsCompleted = null, Action<Exception> onError = null, Action onFinally = null)
        {
            WebClient webClient = new WebClient();

            // register on download complete event
            webClient.OpenReadCompleted += delegate(object sender, OpenReadCompletedEventArgs e)
            {
                try
                {
                    // report error
                    if (e.Error != null)
                    {
                        if (onError != null)
                        {
                            onError(e.Error);
                        }
                        return;
                    }

                    // convert rss result to model
                    List<RssItem> rssItems = new List<RssItem>();
                    Stream stream = e.Result;
//                    Stream stream = XmlObjectSerializerReadObject("/Sample/eng_RSSFeedSample.xml");

                    //XmlReader response = XmlReader.Create(stream);
                    MyXmlReader response = new MyXmlReader(stream);

                    SyndicationFeed feeds = SyndicationFeed.Load(response);


                    foreach (SyndicationItem f in feeds.Items)
                    {
                        RssItem rssItem = new RssItem(f.Title.Text, f.Summary.Text, f.LastUpdatedTime.ToString(), f.Links[0].Uri.AbsoluteUri);
                        rssItems.Add(rssItem);
                    }

                    // notify completed callback
                    if (onGetRssItemsCompleted != null)
                    {
                        onGetRssItemsCompleted(rssItems);
                    }
                }
                finally
                {
                    // notify finally callback
                    if (onFinally != null)
                    {
                        onFinally();
                    }
                }
            };

            webClient.OpenReadAsync(new Uri(rssFeed));
        }
    }

 class MyXmlReader : XmlReader
 {
     XmlReader innerReader;

     private bool readingDate = false;
     private bool dcDate = false;
     const string CustomUtcDateTimeFormat = "dd HH:mm:ss ZZZ yyyy"; // Wed, Oct 07 08:00:07 GMT 2009
     //     const string CustomUtcDateTimeFormat = "ddd, dd MMM yyyy HH:mm:ss ZZZ"; // Wed Oct 07 08:00:07 GMT 2009

//     const string CustomUtcDateTimeFormat = ",ddd MMM dd HH:mm:ss Z yyyy"; // Wed Oct 07 08:00:07 GMT 2009

     //ICRC(ara):    <pubDate>ر, 3 أكت 2012 08:57:12 GMT</pubDate>
     //RSS20:       <pubDate>Sun, 19 May 2002 15:21:36 GMT</pubDate>

     public MyXmlReader(Stream s)
     {
         innerReader = XmlReader.Create(s);
     }

     public override void ReadStartElement()
     {
         if (string.Equals(innerReader.NamespaceURI, string.Empty, StringComparison.InvariantCultureIgnoreCase) &&
             (string.Equals(innerReader.LocalName, "lastBuildDate", StringComparison.InvariantCultureIgnoreCase) ||
             string.Equals(innerReader.LocalName, "pubDate", StringComparison.InvariantCultureIgnoreCase)))
         {
             readingDate = true;
         }

         if (string.Equals(innerReader.NamespaceURI, "dc:date", StringComparison.InvariantCultureIgnoreCase))
         {
             dcDate = true;
         }

         innerReader.ReadStartElement();
     }

     public override void ReadEndElement()
     {
         if (readingDate)
         {
             readingDate = false;
         }
         innerReader.ReadEndElement();
     }

     public override string Value
     {
         get
         {

             if (readingDate)
             {
                // Get Pubdate, LastBuildDate or dc:date value from stream
                 string dateString = innerReader.Value;

                 // Form dummy datestring for PubDate to avoid SyndicationFeed international issues
                 string DummyPubDate = DateTime.Today.ToString();

                     DateTime dt;
                     //If DateTime needs formatting to play nicely with SyndicationFeed API
                     if (!DateTime.TryParse(dateString, out dt))    //If DateTime needs formatting to play nicely with SyndicationFeed API
                         try
                         {
                             // Try to parse it and make it well-formed RSS
                             dt = DateTime.ParseExact(dateString, CustomUtcDateTimeFormat, CultureInfo.InvariantCulture); 
                         }
                         catch
                         {
                             // If it can't be parsed as a DateTime then give it a well-formed RSS dummy value
                             dt = DateTime.Today;
                         }
                 // Otherwise, return 
                 return dt.ToUniversalTime().ToString("R", CultureInfo.InvariantCulture);
             }
             else
             {
                 return innerReader.Value;
             }
         }
     }

     public override int AttributeCount
     {
         get { return innerReader.AttributeCount; }
     }

     public override string BaseURI
     {
         get { throw new NotImplementedException(); }
     }

     public override int Depth
     {
         get { return innerReader.Depth; }
     }

     public override bool EOF
     {
         get { throw new NotImplementedException(); }
     }

     public override string GetAttribute(string name, string namespaceURI)
     {
         return innerReader.GetAttribute(name, namespaceURI);
     }

     public override string GetAttribute(string name)
     {
         throw new NotImplementedException();
     }

     public override string GetAttribute(int i)
     {
         throw new NotImplementedException();
     }

     public override bool IsEmptyElement
     {
         get { return innerReader.IsEmptyElement; }
     }

     public override string LocalName
     {
         get { return innerReader.LocalName; }
     }

     public override string LookupNamespace(string prefix)
     {
         throw new NotImplementedException();
     }

     public override bool MoveToAttribute(string name, string ns)
     {
         throw new NotImplementedException();
     }

     public override bool MoveToAttribute(string name)
     {
         throw new NotImplementedException();
     }

     public override bool MoveToElement()
     {
         return innerReader.MoveToElement();
     }

     public override bool MoveToFirstAttribute()
     {
         return innerReader.MoveToFirstAttribute();
     }

     public override bool MoveToNextAttribute()
     {
         return innerReader.MoveToNextAttribute();
     }

     public override XmlNameTable NameTable
     {
         get { throw new NotImplementedException(); }
     }

     public override string NamespaceURI
     {
         get { return innerReader.NamespaceURI; }
     }

     public override XmlNodeType NodeType
     {
         get { return innerReader.NodeType; }
     }

     public override string Prefix
     {
         get { return innerReader.Prefix; }
     }

     public override bool Read()
     {
         return innerReader.Read();
     }

     public override bool ReadAttributeValue()
     {
         throw new NotImplementedException();
     }

     public override ReadState ReadState
     {
         get { return innerReader.ReadState; }
     }

     public override void ResolveEntity()
     {
         throw new NotImplementedException();
     }

 }

}

/* From (http://support.microsoft.com/kb/2020488)
 // Change SqlServerName, UserId and Password in the following connection string.

 {
     string conn = "Server=<SQLServerName>; database=Northwind; user id=<UserID>; password=<Password>;";
     SqlConnection connection = new SqlConnection();
     connection.ConnectionString = conn;

     DataSet objDataSet = new DataSet();
     SqlDataAdapter objAdapter = new SqlDataAdapter();
     SqlCommand objCmd = new SqlCommand();

 // Retrieve the first 10 records from the employees table.
     objCmd.CommandText = "select top 10 FirstName,BirthDate from employees";
     objCmd.Connection = connection;
     objAdapter.SelectCommand = objCmd;
     objAdapter.Fill(objDataSet);

     connection.Close();

 // Create an instance of XmlTextReader class that reads the XML data.
     XmlTextReader xmlReader = new XmlTextReader(objDataSet.GetXml(), XmlNodeType.Element, null);

     Response.ContentType = "text/xml";
     XmlTextWriter xmlWriter = new XmlTextWriter(Response.OutputStream, Encoding.UTF8);
     xmlWriter.Indentation = 4;
     xmlWriter.WriteStartDocument();
     string elementName = "";

 // Parse & display each node
     while (xmlReader.Read()) {
         switch (xmlReader.NodeType) {
             case XmlNodeType.Element:
                 xmlWriter.WriteStartElement(xmlReader.Name);
                 elementName = xmlReader.Name;

                 break;
             case XmlNodeType.Text:
                 if (elementName.ToLower() == "birthdate") {
                     xmlWriter.WriteString(XmlConvert.ToDateTime(xmlReader.Value).ToString());
                 } else {
                     xmlWriter.WriteString(xmlReader.Value);
                 }

                 break;
             case XmlNodeType.EndElement:
                 xmlWriter.WriteEndElement();

                 break;
         }
     }
     xmlWriter.Close();
 }
Lastly        
  * 
  * XmlReader r = new MyXmlReader(url);

SyndicationFeed feed = SyndicationFeed.Load(r);


Rss20FeedFormatter rssFormatter = feed.GetRss20Formatter();

XmlTextWriter rssWriter = new XmlTextWriter("rss.xml", Encoding.UTF8);

rssWriter.Formatting = Formatting.Indented;

rssFormatter.WriteTo(rssWriter);
rssWriter.Close();


 class MyXmlReader : XmlTextReader
 {
     private bool readingDate = false;
     const string CustomUtcDateTimeFormat = "ddd MMM dd HH:mm:ss Z yyyy"; // Wed Oct 07 08:00:07 GMT 2009

     public MyXmlReader(Stream s) : base(s) { }

     public MyXmlReader(string inputUri) : base(inputUri) { }

     public override void ReadStartElement()
     {
         if (string.Equals(base.NamespaceURI, string.Empty, StringComparison.InvariantCultureIgnoreCase) &&
             (string.Equals(base.LocalName, "lastBuildDate", StringComparison.InvariantCultureIgnoreCase) ||
             string.Equals(base.LocalName, "pubDate", StringComparison.InvariantCultureIgnoreCase)))
         {
             readingDate = true;
         }
         base.ReadStartElement();
     }

     public override void ReadEndElement()
     {
         if (readingDate)
         {
             readingDate = false;
         }
         base.ReadEndElement();
     }

     public override string ReadString()
     {
         if (readingDate)
         {
             string dateString = base.ReadString();
             DateTime dt;
             if(!DateTime.TryParse(dateString,out dt))
                 dt = DateTime.ParseExact(dateString, CustomUtcDateTimeFormat, CultureInfo.InvariantCulture);
             return dt.ToUniversalTime().ToString("R", CultureInfo.InvariantCulture);
         }
         else
         {
             return base.ReadString();
         }
     }
 }

     */