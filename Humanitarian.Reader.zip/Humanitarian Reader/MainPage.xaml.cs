﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Humanitarian_Reader.Resources;
using Humanitarian_Reader.ViewModels;
using System.Globalization;
using System.Threading;
using System.Windows.Markup;
using System.Windows.Media.Imaging;
using Microsoft.ApplicationInsights.Telemetry.WindowsStore;

namespace Humanitarian_Reader
{


    public partial class MainPage : PhoneApplicationPage
    {
        public string RSSLocale;

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            RSSLocale = "";
            SetUILanguage(CultureInfo.CurrentUICulture.Name);
            ClientAnalyticsChannel.Default.LogEvent("Main/NavigatedTo");
        }


        private void SetUILanguage(string locale)
        {
            ClientAnalyticsChannel.Default.LogEvent("LanguageSwitch/" + locale);

            // DEBUG
            string Locale = "Changing from " + CultureInfo.CurrentUICulture.ToString() + " to " + locale + "\n";
            string FlowDirectionBefore = "Root FD before change = " + App.RootFrame.FlowDirection.ToString() + "\n";
            string ResourceFlowDirectionBefore = "AppResources.Resource.FD before change = " + AppResources.ResourceFlowDirection + "\n";
            string LanguageBefore = "Root Lang before change = " + App.RootFrame.Language.IetfLanguageTag.ToString() + "\n";
            string ResourceLanguageBefore = "Appresources.Resource.Lang before change = " + AppResources.ResourceLanguage + "\n";

            // // set this thread's current culture to the culture associated with the selected locale
            CultureInfo newCulture = new CultureInfo(locale);
            Thread.CurrentThread.CurrentCulture = newCulture;
            Thread.CurrentThread.CurrentUICulture = newCulture;

            switch (CultureInfo.CurrentUICulture.TwoLetterISOLanguageName.ToString())
            {
                case "ar": RSSLocale = "ara"; break;
                case "zh": RSSLocale = "chi"; break;
                case "en": RSSLocale = "eng"; break;
                case "es": RSSLocale = "spa"; break;
            }

            FlowDirection flow = (FlowDirection)Enum.Parse(typeof(FlowDirection), AppResources.ResourceFlowDirection);
            App.RootFrame.FlowDirection = flow;

            App.RootFrame.Language = XmlLanguage.GetLanguage(AppResources.ResourceLanguage);

            // DEBUG
            string FlowDirectionAfter = "Root FD after change = " + App.RootFrame.FlowDirection.ToString() + "\n";
            string ResourceFlowDirectionAfter = "AppResources.Resource.FD after change = " + AppResources.ResourceFlowDirection + "\n";
            string LanguageAfter = "Root Lang after change = " + App.RootFrame.Language.IetfLanguageTag.ToString() + "\n";
            string ResourceLanguageAfter = "AppResources.Resource.Lang after change = " + AppResources.ResourceLanguage + "\n";

            MessageBox.Show(Locale + "\n" +
                            FlowDirectionBefore + FlowDirectionAfter + ResourceFlowDirectionBefore + ResourceFlowDirectionAfter + "\n" +
                            LanguageBefore + LanguageAfter + ResourceLanguageBefore + ResourceLanguageAfter);

            //Modify position of the logo image depending on FlowDirection
            bool isFlowRTL = AppResources.ResourceFlowDirection == "RightToLeft" ? true : false;
            if (isFlowRTL)
            {
                GoToNewsImage.Source = new BitmapImage(new Uri("Assets/rtlGoToNews.png", UriKind.RelativeOrAbsolute));
            }
            else
            {
                GoToNewsImage.Source = new BitmapImage(new Uri("Assets/ltrGoToNews.png", UriKind.RelativeOrAbsolute));
            }

            AppTitleTextBlock.Language = XmlLanguage.GetLanguage(locale);
            AppTitleTextBlock.Text = AppResources.ApplicationTitle;

            PageTitleTextBlock.Language = XmlLanguage.GetLanguage(locale);
            PageTitleTextBlock.Text = AppResources.PageTitle;

            MissionTextBlock.Language = XmlLanguage.GetLanguage(locale);
            MissionTextBlock.Text = AppResources.MissionText;

            GoToNewsTextBlock.Language = XmlLanguage.GetLanguage(locale);
            GoToNewsTextBlock.Text = AppResources.GoToNews;

            DisclaimerTextBlock.Language = XmlLanguage.GetLanguage(locale);
            DisclaimerTextBlock.Text = AppResources.DisclaimerText;


            BuildLocalizedApplicationBar();

        }


        // Sample code for building a localized ApplicationBar
        private void BuildLocalizedApplicationBar()
        {
            // Set the page's ApplicationBar to a new instance of ApplicationBar.
            ApplicationBar = new ApplicationBar();


            // Create a new menu item with hard coded language strings.
            ApplicationBarMenuItem ar_appBarMenuItem = new ApplicationBarMenuItem("العربية");
            ApplicationBar.MenuItems.Add(ar_appBarMenuItem);
            ar_appBarMenuItem.Click += new EventHandler(ar_appBarMenuItem_Click);

            ApplicationBarMenuItem zh_appBarMenuItem = new ApplicationBarMenuItem("中文");
            ApplicationBar.MenuItems.Add(zh_appBarMenuItem);
            zh_appBarMenuItem.Click += new EventHandler(zh_appBarMenuItem_Click);

            ApplicationBarMenuItem en_appBarMenuItem = new ApplicationBarMenuItem("english");
            ApplicationBar.MenuItems.Add(en_appBarMenuItem);
            en_appBarMenuItem.Click += new EventHandler(en_appBarMenuItem_Click);

            ApplicationBarMenuItem es_appBarMenuItem = new ApplicationBarMenuItem("español");
            ApplicationBar.MenuItems.Add(es_appBarMenuItem);
            es_appBarMenuItem.Click += new EventHandler(es_appBarMenuItem_Click);

            // Create a new menu item with the localized string from AppResources.
            ApplicationBarMenuItem about_appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarAboutMenuItem);
            ApplicationBar.MenuItems.Add(about_appBarMenuItem);

        }

        private void es_appBarMenuItem_Click(object sender, EventArgs e)
        {
            SetUILanguage("es-ES");
        }

        private void en_appBarMenuItem_Click(object sender, EventArgs e)
        {
            SetUILanguage("en-US");
        }

        private void zh_appBarMenuItem_Click(object sender, EventArgs e)
        {
            SetUILanguage("zh-Hans");
       } 

        private void ar_appBarMenuItem_Click(object sender, EventArgs e)
        {
            SetUILanguage("ar-SA");
        }

        private void GoToNews_Tap(object sender, System.Windows.Input.GestureEventArgs e)
        {
            string RSSURLStart = "http://www.icrc.org/";
            string RSSURLEnd = "/home/rss-feed/news-feed.xml";

            //            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
            NavigationService.Navigate(new Uri("/ArticleView.xaml?RSSFeed=" + RSSURLStart + RSSLocale + RSSURLEnd, UriKind.Relative));
        }


    }
}