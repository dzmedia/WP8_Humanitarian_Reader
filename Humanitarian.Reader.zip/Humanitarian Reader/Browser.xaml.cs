﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;
using Humanitarian_Reader.Resources;
using System.Windows.Media.Imaging;

namespace Humanitarian_Reader
{
    public partial class Browser : PhoneApplicationPage
    {
        bool isFlowRTL = AppResources.ResourceFlowDirection == "RightToLeft" ? true : false;

        List<string> URLHistoryStack = new List<string>();
        int PositionIndex = -1;
        bool IsNavigationButtonClicked = false;
        
        public Browser()
        {
            InitializeComponent();
//            SetUILanguage();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            string uri = "";
            if (NavigationContext.QueryString.TryGetValue("SelectedArticle", out uri))
            {
                webBrowser1.Navigate(new Uri(uri, UriKind.Absolute)); // set the intial click url
            }
        }

        private void Button_Click_LeftBrowseArrow(object sender, RoutedEventArgs e)
        {
            string dir = isFlowRTL ? "forward" : "backward";
            BrowserNav(dir); 

        }

        private void Button_Click_RightBrowseArrow(object sender, RoutedEventArgs e)
        {
            string dir = isFlowRTL ? "backward" : "forward";
            BrowserNav(dir); 
        }


        private void BrowserNav(string dir)
        {
            if (dir == "forward")
            {
                if (this.URLHistoryStack.Count > PositionIndex + 1)
                {
                    // Add this url to the history and increment the index
                    this.IsNavigationButtonClicked = true;
                    this.webBrowser1.Navigate(new Uri(this.URLHistoryStack[PositionIndex + 1].ToString()));
                    PositionIndex++;
                }
            }
            else
            {
                if (PositionIndex <= 0)
                {
                    // He came to the first page and may be wants to go back to ArticleView
                    NavigationService.Navigate(new Uri("/ArticleView.xaml", UriKind.Relative));
                }
                else
                {
                    // Add this url to the history and decrement the index
                    this.IsNavigationButtonClicked = true;
                    this.webBrowser1.Navigate(new Uri(this.URLHistoryStack[PositionIndex - 1].ToString()));
                    PositionIndex--;
                }
            }

        }
        
        
        private void webBrowser1_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            if (this.webBrowser1.Source != null && !this.IsNavigationButtonClicked)
            {
                if (PositionIndex == 0)
                {
                    // This is the first page, so clear the old history if any and add this a fresh
                    string firstURL = this.URLHistoryStack[0];
                    this.URLHistoryStack.Clear();
                    this.URLHistoryStack.Add(firstURL);
                }
                // Add this url to the history and increment the index
                this.URLHistoryStack.Add(this.webBrowser1.Source.ToString());
                PositionIndex++;
            }
            this.IsNavigationButtonClicked = false;
        }


        private void Button_Click_Home(object sender, RoutedEventArgs e)
        {
            // Jump to Home page
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }

        private void Button_Click_Articles(object sender, RoutedEventArgs e)
        {
            PositionIndex = 0;
            // Jump to Article view page
            NavigationService.Navigate(new Uri("/ArticleView.xaml", UriKind.Relative));
        }

        private void SetUILanguage()
        {
            bool isFlowRTL = AppResources.ResourceFlowDirection == "RightToLeft" ? true : false;
            if (isFlowRTL)
            {
                LogoImage.Margin = new Thickness(12, 0, 0, 0);
                //BackToArticlesButtonImage.ImageSource = new BitmapImage(new Uri("Assets/ltrGoToNews.png", UriKind.RelativeOrAbsolute));
            }
            else
            {
                LogoImage.Margin = new Thickness(421, 0, 0, 0);
                //BackToArticlesButtonImage.ImageSource = new BitmapImage(new Uri("Assets/rtlGoToNews.png", UriKind.RelativeOrAbsolute));
            }

        }

        
    }
}
