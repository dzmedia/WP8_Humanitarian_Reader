﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AppXamlUninstaller.cs" company="Microsoft Corporation">
//   2012-2023, All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Microsoft.ApplicationInsights.Telemetry.WindowsStore.NuGet
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Xml.Linq;

    public class AppXamlUninstaller : XmlFileTransformer
    {
        protected override XDocument Transform(XDocument document)
        {
            XNamespace applicationInsightsNamespace = XNamespace.Get(this.ApplicationInsightsNamespace);
            List<XElement> applicationInsightsModules = document.Root.Descendants(applicationInsightsNamespace + "ApplicationInsightsModule").ToList();
            applicationInsightsModules.ForEach(this.Remove);
            return document;
        }

        private void Remove(XElement element)
        {
            XElement parent = element.Parent;

            element.Remove();

            if (parent != parent.Document.Root && !parent.Nodes().Any())
            {
                this.Remove(parent);
            }
        }
    }
}
