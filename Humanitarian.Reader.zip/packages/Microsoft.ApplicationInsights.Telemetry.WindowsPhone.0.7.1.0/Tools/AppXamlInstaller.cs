﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AppXamlInstaller.cs" company="Microsoft Corporation">
//   2012-2023, All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Microsoft.ApplicationInsights.Telemetry.WindowsStore.NuGet
{
    using System;
    using System.Linq;
    using System.Diagnostics;
    using System.Xml.Linq;

    public class AppXamlInstaller : XmlFileTransformer
    {
        private static readonly string ResourcesElementNameSuffix = ".Resources";
        private static readonly string AINamespacePrefix = "ai";
        private static readonly XName MergedDictionariesElementName = PresentationNamespace + "ResourceDictionary.MergedDictionaries";
        private static readonly XName ResourceDictionaryElementName = PresentationNamespace + "ResourceDictionary";

        protected override XDocument Transform(XDocument document)
        {
            XElement application = document.Root;

            // Add <Application.Resources> if it doesn't exist
            XName applicationResourcesElementName = application.Name + ResourcesElementNameSuffix;
            XElement applicationResources = application.Element(applicationResourcesElementName);
            if (applicationResources == null)
            {
                applicationResources = new XElement(applicationResourcesElementName);
                application.Add(applicationResources);
            }

            // Add <ResourceDictionary> if it doesn't exist (and move existing resources into it)
            XElement resourceDictionary = applicationResources.Element(ResourceDictionaryElementName);
            if (resourceDictionary == null)
            {
                resourceDictionary = new XElement(ResourceDictionaryElementName);
                resourceDictionary.Add(applicationResources.Elements().ToList());
                applicationResources.RemoveAll();
                applicationResources.Add(resourceDictionary);
            }

            // Add <ResourceDictionary.MergedDictionaries> if it doesnt exist
            XElement mergedDictionaries = resourceDictionary.Element(MergedDictionariesElementName);
            if (mergedDictionaries == null)
            {
                mergedDictionaries = new XElement(MergedDictionariesElementName);
                resourceDictionary.Add(mergedDictionaries);
            }

            XNamespace applicationInsightsNamespace = XNamespace.Get(this.ApplicationInsightsNamespace);
            XName applicationInsightsModuleElementName = applicationInsightsNamespace + "ApplicationInsightsModule";
            if (!mergedDictionaries.Descendants(applicationInsightsModuleElementName).Any())
            {
                XElement childResourceDictionary = new XElement(ResourceDictionaryElementName);
                childResourceDictionary.Add(new XElement(
                    applicationInsightsModuleElementName,
                    new XAttribute(XamlNamespace + "Key", "ApplicationInsightsModule"),
                    new XAttribute(XNamespace.Xmlns + AINamespacePrefix, applicationInsightsNamespace)));
                mergedDictionaries.Add(childResourceDictionary);
            }

            return document;
        }
    }
}
