﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="XmlFileTransformer.cs" company="Microsoft Corporation">
//   2012-2023, All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Microsoft.ApplicationInsights.Telemetry.WindowsStore.NuGet
{
    using EnvDTE;
    using System;
    using System.IO;
    using System.Xml;
    using System.Xml.Linq;
    using System.ComponentModel;
    using System.Text;

    public abstract class XmlFileTransformer
    {
        public static readonly XNamespace PresentationNamespace = "http://schemas.microsoft.com/winfx/2006/xaml/presentation";
        public static readonly XNamespace XamlNamespace = "http://schemas.microsoft.com/winfx/2006/xaml";

        /// <summary>
        /// Gets or sets the <see cref="DTE.SourceControl"/> object used to check out the transformed file.
        /// </summary>
        /// <remarks>
        /// This property is of type <see cref="object"/> instead of <see cref="EnvDTE.SourceControl"/>
        /// because PowerShell encounters a run-time error trying to assign a strongly-typed property.
        /// </remarks>
        public object SourceControl { get; set; }

        /// <summary>
        /// Gets or sets the Application Insights namespace. Depending on whether this installer is targetting Windows Store or
        /// Windows Phone, this namespace can be different.
        /// </summary>
        /// <remarks>
        /// This property is of type <see cref="object"/> instead of <see cref="System.String"/>
        /// because PowerShell encounters a run-time error trying to assign a strongly-typed property.
        /// </remarks>
        public string ApplicationInsightsNamespace { get; set; }

        /// <summary>
        /// Gets or sets the <see cref="DTE.Documents"/> object used to save changes made in Visual Studio editor.
        /// </summary>
        /// <remarks>
        /// This property is of type <see cref="object"/> instead of <see cref="EnvDTE.Documents"/>
        /// because PowerShell encounters a run-time error trying to assign a strongly-typed property.
        /// </remarks>
        public object Documents { get; set; }

        public void TransformFile(string filePath)
        {
            // Make file writeable
            FileAttributes fileAttributes = File.GetAttributes(filePath);
            if ((fileAttributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
            {
                File.SetAttributes(filePath, fileAttributes & ~FileAttributes.ReadOnly);
            }

            // Check file out of source control
            var sourceControl = (SourceControl)this.SourceControl;
            if (sourceControl != null && 
                sourceControl.IsItemUnderSCC(filePath) && 
                sourceControl.IsItemCheckedOut(filePath) == false)
            {
                sourceControl.CheckOutItem(filePath);
            }

            // Save changes made in Visual Studio editor
            var documents = (Documents)this.Documents;
            if (documents != null)
            {
                foreach (Document document in documents)
                {
                    if (!document.Saved && string.Equals(document.FullName, filePath, StringComparison.OrdinalIgnoreCase))
                    {
                        document.Save();
                    }
                }
            }

            XDocument original = LoadXml(filePath);

            // Transform file
            XDocument transformed = this.Transform(original);
            XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
            xmlWriterSettings.OmitXmlDeclaration = original.Declaration == null;
            xmlWriterSettings.Indent = true;
            if (original.Declaration != null && !string.IsNullOrEmpty(original.Declaration.Encoding))
            {
                xmlWriterSettings.Encoding = Encoding.GetEncoding(original.Declaration.Encoding);
            }

            using (XmlWriter xmlWriter = XmlWriter.Create(filePath, xmlWriterSettings))
            {
                transformed.WriteTo(xmlWriter);
            }
        }

        private static XDocument LoadXml(string filePath)
        {
            try
            {
                return XDocument.Load(filePath);
            }
            catch (XmlException e)
            {
                throw new WarningException(
                    string.Format("Unable to load XML file '{0}'. {1}", filePath, e.Message),
                    e);
            }
        }

        protected abstract XDocument Transform(XDocument document);
    }
}
